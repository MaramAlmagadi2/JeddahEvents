const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'jeddahevent',
  port: 3306,
});

module.exports = connection;
