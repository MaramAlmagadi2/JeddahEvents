const express = require('express');
const { body, validationResult } = require('express-validator');
const router = express.Router();
const connection = require('../database');

// Display the contact form
router.get('/', (req, res) => {
  res.render('contact');
});

// Display all contact data
router.get('/data', (req, res) => {
  const query = 'SELECT * FROM contact_us';
  connection.query(query, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }
    res.render('contactUs', { contactUsData: results });
  });
});

// Validation middleware for the contact form submission
const validateContactForm = [
  body('firstName').trim().notEmpty().withMessage('First name is required'),
  body('lastName').trim().notEmpty().withMessage('Last name is required'),
  body('gender').trim().notEmpty().withMessage('Gender is required'),
  body('mobile').trim().notEmpty().withMessage('Mobile number is required').isLength({ min: 10, max: 10 }).withMessage('Mobile number must be 10 characters long'),
  body('dob').trim().notEmpty().withMessage('Date of birth is required'),
  body('email').trim().isEmail().withMessage('Invalid email address'),
  body('language').trim().notEmpty().withMessage('Language is required'),
  body('message').trim().notEmpty().withMessage('Message is required'),
];

// Insert a new contact form submission
router.post('/', validateContactForm, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { firstName, lastName, gender, mobile, dob, email, language, message } = req.body;

  const query = 'INSERT INTO contact_us (first_name, last_name, gender, mobile, dob, email, language, message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  connection.query(query, [firstName, lastName, gender, mobile, dob, email, language, message], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    res.json({ successMessage: 'Form submitted successfully!' });
  });
});

// Update a contact form submission by id
router.post('/update/:id', validateContactForm, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { firstName, lastName, gender, mobile, dob, email, language, message } = req.body;
  const id = req.params.id;
  const query = 'UPDATE contact_us SET first_name=?, last_name=?, gender=?, mobile=?, dob=?, email=?, language=?, message=? WHERE id=?';
  connection.query(query, [firstName, lastName, gender, mobile, dob, email, language, message, id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    res.redirect('/contact/data'); // Redirect to the contact data page after successful update
  });
});

// Delete a contact form submission by id
router.post('/delete/:id', (req, res) => {
  const id = req.params.id;

  const query = 'DELETE FROM contact_us WHERE id=?';
  connection.query(query, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    res.redirect('/contact/data'); // Redirect to the contact data page after successful delete
  });
});

module.exports = router;
