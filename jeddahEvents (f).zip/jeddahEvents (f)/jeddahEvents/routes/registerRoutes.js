const express = require('express');
const cookieParser = require('cookie-parser');
const router = express.Router();
const connection = require('../database');

// Route for rendering the login form
router.get('/', (req, res) => {
  res.render('register');
});
// Route for handling registration form submission (POST request)
router.post('/', (req, res) => {
  const { username, email, password } = req.body;

  // Validate form data (you can add more validation as needed)

  // Check if the email is already registered
  const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
  connection.query(checkEmailQuery, [email], (err, existingUser) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    if (existingUser.length > 0) {
      // Email already exists, redirect to registration page with an error message
      res.redirect('/?error=Email already exists');
    } else {
      // Insert the new user into the 'users' table
      const insertUserQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
      connection.query(insertUserQuery, [username, email, password], (err, results) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Internal Server Error');
        }

        // Set userLogin flag in localStorage after successful registration
        res.cookie('userLogin', true);

        // Redirect to login page or perform any other action after successful registration
        res.redirect('/home');
      });
    }
  });
});

module.exports = router;