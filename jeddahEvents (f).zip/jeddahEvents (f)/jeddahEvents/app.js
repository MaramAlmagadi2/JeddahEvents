// app.js

const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const loginRoutes = require('./routes/loginRoutes');
const registerRoutes = require('./routes/registerRoutes');
const contactRoutes = require('./routes/contactRoutes');
const aboutRoutes = require('./routes/aboutRoutes');
const scedualRoutes = require('./routes/scedualRoutes');
const eventRoutes = require('./routes/eventRoutes');
const mainRoutes = require('./routes/mainRoutes');




const isAuthenticated = require('./Middleware/auth');
const connection = require('./database');

const app = express();
const port = 5000;

app.use(cookieParser());

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use('/', loginRoutes);
app.use('/register', registerRoutes);

app.use('/logout', (req, res) => {
  // Clear the 'userLogin' cookie on logout
  res.clearCookie('userLogin');
  res.redirect('/');
});

app.use(isAuthenticated);
app.use('/contact', contactRoutes);
app.use('/about', aboutRoutes);
app.use('/event', eventRoutes);
app.use('/home', mainRoutes);
app.use('/scedual', scedualRoutes);



app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

connection.connect((err) => {
  if (err) {
    console.error('Database connection failed: ', err);
  } else {
    console.log('Connected to MySQL database');
  }
});
